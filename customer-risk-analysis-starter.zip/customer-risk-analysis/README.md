# Customer Risk Analysis

A small practice project for the **Git and GitHub for Analytics, Data Science, and Data Engineering** self-study tutorial.

This starter project is intentionally simple. Its purpose is to provide realistic files for practicing Git in VS Code, not to demonstrate a production risk model.

## Project structure

```text
customer-risk-analysis/
├── README.md
├── data/
│   └── sample_customers.csv
├── notebooks/
│   └── analysis.ipynb
├── src/
│   └── scoring.py
├── tests/
│   └── test_scoring.py
├── requirements.txt
└── .gitignore
```

## Baseline behavior

`src/scoring.py` contains a deliberately simple scoring function:

```python
def calculate_score(income, debt):
    return income - debt
```

The tutorial will ask you to add input validation on a feature branch. **Do not add that validation before the exercise tells you to do so.**

## Run the tests

From the project root:

```bash
python -m pytest
```

## Run the notebook

Open `notebooks/analysis.ipynb` in VS Code with Python/Jupyter support enabled, select a Python kernel, and run the cells.
