"""Simple customer scoring logic used by the Git self-study exercise."""


def calculate_score(income, debt):
    """Return a deliberately simple score: income minus debt."""
    return income - debt
