from src.scoring import calculate_score


def test_calculate_score():
    assert calculate_score(75000, 20000) == 55000


def test_calculate_score_with_zero_debt():
    assert calculate_score(50000, 0) == 50000
